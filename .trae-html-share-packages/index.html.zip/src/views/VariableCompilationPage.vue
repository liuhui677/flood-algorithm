<script setup lang="ts">
// 后续实现 variableCompilation.ts 的演示页面
</script>

<template>
  <div class="placeholder">
    <h2>变量编译功能</h2>
    <p>敬请期待……（后续实现 variableCompilation.ts 的演示）</p>
  </div>
</template>

<style scoped>
.placeholder {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 80vh;
  color: #666;
  font-family: system-ui, sans-serif;
}
.placeholder h2 {
  font-size: 24px;
  color: #333;
  margin-bottom: 12px;
}
.placeholder p {
  font-size: 14px;
}
</style>
